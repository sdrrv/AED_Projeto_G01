from .tad_stack import Stack


@unittest.SkipTest
class ArrayStack(Stack):
    def is_empty(self): pass

    def is_full(self): pass

    def size(self): pass

    def top(self): pass

    def push(self, element): pass

    def pop(self): pass

