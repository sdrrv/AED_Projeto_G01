from .tad_queue import Queue

class ArrayQueue(Queue):
    def is_empty(self): pass

    def is_full(self): pass

    def size(self): pass

    def enqueue(self, element): pass

    def dequeue(self): pass